<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Running (Enrollment Opened)</label>
    <protected>false</protected>
    <values>
        <field>rio_ed__Allow_Enrollment__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>rio_ed__Allow_Pre_Enrollment__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>rio_ed__Allow_Unenrollment__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>rio_ed__Cancelled__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>rio_ed__Completed__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>rio_ed__Draft__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>rio_ed__In_Progress__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>rio_ed__Inactive__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>rio_ed__Pending__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>rio_ed__Status__c</field>
        <value xsi:type="xsd:string">Running (Enrollment Opened)</value>
    </values>
</CustomMetadata>
