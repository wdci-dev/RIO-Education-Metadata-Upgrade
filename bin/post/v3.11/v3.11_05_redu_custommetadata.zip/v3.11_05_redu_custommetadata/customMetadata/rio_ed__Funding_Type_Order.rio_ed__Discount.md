<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Discount</label>
    <protected>false</protected>
    <values>
        <field>rio_ed__Funding_Disbursement_Method__c</field>
        <value xsi:type="xsd:string">Fee Line</value>
    </values>
    <values>
        <field>rio_ed__Funding_Type__c</field>
        <value xsi:type="xsd:string">Discount</value>
    </values>
    <values>
        <field>rio_ed__Inactive__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>rio_ed__Order_of_Priority__c</field>
        <value xsi:type="xsd:int">2</value>
    </values>
</CustomMetadata>
