<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Financial Assistance</label>
    <protected>false</protected>
    <values>
        <field>rio_ed__Always_Show__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>rio_ed__Enabled__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>rio_ed__Fee_Type_Option__c</field>
        <value xsi:type="xsd:string">Scholarship</value>
    </values>
    <values>
        <field>rio_ed__Non_Tuition__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>rio_ed__Support_Payment__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>rio_ed__Support_Upfront_Payment__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
</CustomMetadata>
